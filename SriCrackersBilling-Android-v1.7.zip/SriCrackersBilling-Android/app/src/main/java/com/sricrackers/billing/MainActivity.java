package com.sricrackers.billing;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.provider.DocumentsContract;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * Shows the billing app (assets/index.html) full screen and gives it native
 * save, share and print, because a WebView cannot do those by itself.
 * The app needs no internet connection.
 */
public class MainActivity extends Activity {

    private static final int REQ_FILE = 1001;
    private static final int REQ_TREE = 1002;

    private WebView web;
    private WebView printView;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("http://") || url.startsWith("https://")
                        || url.startsWith("sms:") || url.startsWith("smsto:")
                        || url.startsWith("tel:") || url.startsWith("whatsapp:")
                        || url.startsWith("upi:") || url.startsWith("mailto:")) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, request.getUrl()));
                    } catch (Exception ignored) { }
                    return true;
                }
                return false;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                fileCallback = null;
            }
        } else if (requestCode == REQ_TREE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri tree = data.getData();
                try {
                    getContentResolver().takePersistableUriPermission(tree,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                } catch (Exception ignored) { }
                getSharedPreferences("autobackup", Context.MODE_PRIVATE).edit().putString("tree", tree.toString()).apply();
                String id = DocumentsContract.getTreeDocumentId(tree);
                String nm = id.contains(":") ? id.substring(id.indexOf(':') + 1) : id;
                if (nm.isEmpty()) { nm = "Storage root"; }
                final String js = "window.__autoFolder && window.__autoFolder(" + JSONObject.quote(nm) + ")";
                web.post(new Runnable() { public void run() { web.evaluateJavascript(js, null); } });
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    /** Back button: let the app close its preview or go to the Billing tab first. */
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.__back ? window.__back() : false", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (!"true".equals(value)) {
                    finish();
                }
            }
        });
    }

    private void toast(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
            }
        });
    }

    private static String safeName(String name) {
        String n = name == null ? "file" : name.replaceAll("[^A-Za-z0-9._-]", "_");
        return n.isEmpty() ? "file" : n;
    }

    /** Called from the page through window.AndroidBridge (runs on a background thread). */
    public class Bridge {

        /** Saves a file into the phone's Downloads folder. */
        @JavascriptInterface
        public void saveFile(String name, String mime, String base64) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                String fileName = safeName(name);
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) {
                    throw new Exception("Downloads folder is not available");
                }
                OutputStream os = getContentResolver().openOutputStream(uri);
                if (os == null) {
                    throw new Exception("Could not open the file");
                }
                os.write(data);
                os.close();
                toast("Saved in Downloads: " + fileName);
            } catch (Exception e) {
                toast("Could not save the file: " + e.getMessage());
            }
        }

        /** Opens the Android share sheet (WhatsApp, email, Drive and so on) with the file attached. */
        @JavascriptInterface
        public void shareFile(String name, String mime, String base64) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists() && !dir.mkdirs()) {
                    throw new Exception("Could not create a cache folder");
                }
                File file = new File(dir, safeName(name));
                FileOutputStream fo = new FileOutputStream(file);
                fo.write(data);
                fo.close();
                final Uri uri = FileProvider.getUriForFile(MainActivity.this,
                        getPackageName() + ".fileprovider", file);
                final String type = mime;
                final String subject = safeName(name);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType(type);
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.putExtra(Intent.EXTRA_SUBJECT, subject);
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send, "Share bill"));
                    }
                });
            } catch (Exception e) {
                toast("Could not share the file: " + e.getMessage());
            }
        }

        /** Lets the owner choose a folder (phone storage, SD card, Drive, OneDrive...) for automatic backups. */
        @JavascriptInterface
        public void pickBackupFolder() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                        startActivityForResult(i, REQ_TREE);
                    } catch (Exception e) {
                        toast("Could not open the folder chooser: " + e.getMessage());
                    }
                }
            });
        }

        /** Writes (or overwrites) a file in the chosen backup folder. Returns "ok" or a short error. */
        @JavascriptInterface
        public String autoSave(String name, String base64) {
            try {
                String t = getSharedPreferences("autobackup", Context.MODE_PRIVATE).getString("tree", "");
                if (t.isEmpty()) { return "No folder chosen"; }
                Uri tree = Uri.parse(t);
                String docId = DocumentsContract.getTreeDocumentId(tree);
                Uri dir = DocumentsContract.buildDocumentUriUsingTree(tree, docId);
                Uri kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
                String safe = safeName(name);
                Uri file = null;
                Cursor c = getContentResolver().query(kids, new String[]{
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
                if (c != null) {
                    try {
                        while (c.moveToNext()) {
                            if (safe.equals(c.getString(1))) {
                                file = DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0));
                                break;
                            }
                        }
                    } finally { c.close(); }
                }
                if (file == null) {
                    file = DocumentsContract.createDocument(getContentResolver(), dir, "application/json", safe);
                }
                if (file == null) { return "Could not create the file in that folder"; }
                OutputStream os = getContentResolver().openOutputStream(file, "wt");
                if (os == null) { return "Could not open the file"; }
                os.write(Base64.decode(base64, Base64.DEFAULT));
                os.close();
                return "ok";
            } catch (Exception e) {
                return "Folder not available (" + e.getMessage() + "). Choose it again.";
            }
        }

        /**
         * Prints the bill pages (JSON array of JPEG data URLs, one per A4 page).
         * The Android print screen also offers "Save as PDF".
         */
        @JavascriptInterface
        public void printPages(final String jsonPages, final String title) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        JSONArray pages = new JSONArray(jsonPages);
                        StringBuilder html = new StringBuilder();
                        html.append("<html><head><style>@page{margin:0}body{margin:0}")
                            .append("img{display:block;width:100%;page-break-after:always}")
                            .append("img:last-child{page-break-after:auto}</style></head><body>");
                        for (int i = 0; i < pages.length(); i++) {
                            html.append("<img src=\"").append(pages.getString(i)).append("\">");
                        }
                        html.append("</body></html>");

                        printView = new WebView(MainActivity.this);
                        printView.setWebViewClient(new WebViewClient() {
                            @Override
                            public void onPageFinished(WebView view, String url) {
                                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                                PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(title);
                                PrintAttributes attrs = new PrintAttributes.Builder()
                                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                        .build();
                                pm.print(title, adapter, attrs);
                            }
                        });
                        printView.loadDataWithBaseURL(null, html.toString(), "text/html", "UTF-8", null);
                    } catch (Exception e) {
                        toast("Could not print: " + e.getMessage());
                    }
                }
            });
        }
    }
}
